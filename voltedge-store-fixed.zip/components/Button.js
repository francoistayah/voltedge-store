
export default function Button({ children }) {
  return (
    <button style={{
      backgroundColor: '#f97316',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      fontWeight: 'bold'
    }}>
      {children}
    </button>
  );
}
